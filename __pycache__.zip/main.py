import tkinter as tk
from modules.ui import SimonDiceApp

if __name__ == "__main__":
    root = tk.Tk()
    app = SimonDiceApp(root)
    root.mainloop()